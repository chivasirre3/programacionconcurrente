package class1;

public class Example5 {

	
	public static void main(String[] args) {
		// EXERCISE: Create a Thread subclass that generalizes the threads shown
		//	and use it to do the same thing.
	}
	
	
}
