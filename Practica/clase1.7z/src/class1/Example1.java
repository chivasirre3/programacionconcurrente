package class1;

public class Example1 {

	
	/** A program that prints "Hello." every three seconds. */
	public static void main(String[] args) {
		try {

			while (true) {
				System.out.println("Hello.");
				Thread.sleep(3000); // 3000 ms = 3 s
			}

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
}
