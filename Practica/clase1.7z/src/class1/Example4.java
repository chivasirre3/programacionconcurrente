package class1;

public class Example4 {

	
	/** A program that prints "Hello." every three seconds, and "How are you?" every five seconds. */
	public static void main(String[] args) {
		
		new Thread() {
			public void run() {
				try {
					while (true) {
						System.out.println("Hello.");
						Thread.sleep(3000);
					}
				} catch (InterruptedException e) { e.printStackTrace(); }
			}
		}.start();
		
		new Thread(new Runnable() {
			public void run() {
				try {
					while (true) {
						System.out.println("How are you?");
						Thread.sleep(5000);
					}
				} catch (InterruptedException e) { e.printStackTrace(); }
			}
		}).start();
		
	}
	
	
}
