package class1;

public class Example3 {

	
	/** A thread that prints "Hello." every three seconds. */
	public static class HelloThread extends Thread {
		
		public HelloThread() {} // HelloThread constructor (not really necessary)
		
		@Override
		public void run() {
			try {
				while (true) {
					System.out.println("Hello.");
					Thread.sleep(3000);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	/** A runnable that prints "How are you?" every five seconds. */
	public static class HowAreYouRunnable implements Runnable {
		@Override
		public void run() {
			try {
				while (true) {
					System.out.println("How are you?");
					Thread.sleep(5000);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	
	/** A program that prints "Hello." every three seconds, and "How are you?" every five seconds. */
	public static void main(String[] args) {
		
		Thread helloThread = new HelloThread();
		Thread howAreYouThread = new Thread(new HowAreYouRunnable());
		
		helloThread.start();
		howAreYouThread.start();
		
	}
	
	
}
