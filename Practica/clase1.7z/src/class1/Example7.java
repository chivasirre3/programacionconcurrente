package class1;
import java.util.ArrayList;
import java.util.Collections;

import static java.util.Collections.max;


/* Idem Exmple6 but using Bakery algorithm to avoid any problems. */
public class Example7 {

	/** Number of threads to launch. */
	public static final int THREADS = 200;
	
	/** Boolean Array that indicates if the i-th thread is entering the critical section. */
	public static boolean[] entering = new boolean[THREADS];
	
	/** List with the the bakery number for the i-th thread. */
	public static ArrayList<Integer> number = new ArrayList<Integer>(THREADS);
	
	
	/** Shared variable. */
	public static int counter = 0;
	
	
	/** A thread that increments the shared counter and dies. */
	public static class IncThread extends Thread {
		
		/** Id of the this thread. */
		private int threadId;
		
		/** Constructor of a IncThread, requires an id to be created. */
		public IncThread(int threadId) {
			this.threadId = threadId;
		}
		
		
		/** Thread run method. */
		@Override
		public void run() {
			entering[threadId] = true;
			number.set(threadId, 1 + max(number));
			entering[threadId] = false;
			
			for (int i = 0; i < THREADS; i++) {
				while (entering[i])
					Thread.yield();
				while (
					number.get(i) != 0 && (
						number.get(i) < number.get(threadId) ||
						(number.get(i) == number.get(threadId) && i < threadId)
					)
				) {
					Thread.yield();
				}
			}
			
			// BEGIN CRITICAL SECTION
			System.out.print("Previous: " + Example7.counter);
			Example7.counter++;
			System.out.println(" - Current: " + Example7.counter);
			// END CRITICAL SECTION
			
			number.set(threadId, 0);
		}
	}
	
	
	/** A program that starts three thousand IncThreads. */
	public static void main(String[] args) {
		number.addAll(Collections.nCopies(THREADS, 0));
		for (int i = 0; i < THREADS; i++)
			new IncThread(i).start();
	}
	
}
