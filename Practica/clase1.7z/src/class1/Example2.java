package class1;

public class Example2 {

	
	/** A program that prints "Hello." every three seconds, and "How are you?" every five seconds. */
	public static void main(String[] args) throws InterruptedException {
		
		for (int i = 0; true; i++) {
			
			if (i % 3 == 0)
				System.out.println("Hello.");
			
			if (i % 5 == 0)
				System.out.println("How are you?");
			
			Thread.sleep(1000);
			
		}

	}
	
	
}
