package class1;

public class Example6 {

	/** Number of threads to launch. */
	public static final int THREADS = 3000;
	
	/** Shared variable. */
	public static int counter = 0;
	
	
	/** A thread that increments the shared counter and dies. */
	public static class IncThread extends Thread {
		@Override
		public void run() {
			System.out.print("Previous: " + Example6.counter);
			Example6.counter++;
			System.out.println(" - Current: " + Example6.counter);
		}
	}
	
	
	/** A program that starts three thousand IncThreads. */
	public static void main(String[] args) {
		for (int i = 0; i < THREADS; i++)
			new IncThread().start();
	}
	
	
	// EXERCISE: Identify the shared resources and the critical section.
	
}
